jQuery(document).ready( function($) {



	if( $('.mtphr-dnt-image-gallery').length > 0 ) {
	
		function mtphr_dnt_image_button_toggle( $table ) {
			if( $table.find('.mtphr-dnt-list-item').length > 1 ) {
				$table.find('.mtphr-dnt-list-handle').show();
			} else {
				$table.find('.mtphr-dnt-list-handle').hide();
			}
			
			mtphr_dnt_image_button_toggle( $table );
		}
	
		function mtphr_dnt_image_order( $table ) {
	
			// Set the order of the items
			$table.find('.mtphr-dnt-list-item').each( function(i) {
				$(this).find('input,textarea,select').each( function(e) {
					var field = $(this).attr('field');
					$(this).attr('name', '_mtphr_dnt_image_ticks['+i+']['+field+']');
				});
			});
		}

		$('.mtphr-dnt-image-gallery').sortable( {
			handle: '.mtphr-dnt-list-handle',
			axis: 'y',
			items: '.mtphr-dnt-list-item',
		  helper: function(e, tr) {
		    var $originals = tr.children();
		    var $helper = tr.clone();
		    $helper.children().each(function(index) {
		      $(this).width($originals.eq(index).width());
		      $(this).height($originals.eq(index).height());
		    });
		    return $helper;
		  },
		  update: function(event, ui) {
		  	var $table = ui.item.parents('.mtphr-dnt-image-gallery');
		  	mtphr_dnt_image_order( $table );
		  }
		});
	
		$('.mtphr-dnt-image-gallery').find('.mtphr-dnt-list-delete').live( 'click', function(e) {
			e.preventDefault();
	
			// Fade out the item
			$(this).parents('.mtphr-dnt-list-item').fadeOut( function() {
				var $table = $(this).parents('.mtphr-dnt-image-gallery');
				$(this).remove();
				mtphr_dnt_image_order( $table );
				mtphr_dnt_image_button_toggle( $table );
			});
		});
	
		$('.mtphr-dnt-image-gallery').find('.mtphr-dnt-list-add').live( 'click', function(e) {
		  e.preventDefault();
	
		  // Save the container
		  var $table = $(this).parents('.mtphr-dnt-image-gallery'),
		  		$item = $(this).parents('.mtphr-dnt-list-item');
		  mtphr_dnt_image_select_images( $table, $item );
	  });
	
		$('.mtphr-dnt-image-add-images').click( function(e) {
		  e.preventDefault();
	
		  // Save the container
		  var $table = $(this).parents('.mtphr-dnt-image-gallery-container').find('.mtphr-dnt-image-gallery'),
		  		$item = $table.find('.mtphr-dnt-list-item:last');
		  mtphr_dnt_image_select_images( $table, $item );
		});
	
		function mtphr_dnt_image_select_images( $table, $item ) {
	
		  // Create a custom uploader
		  var uploader;
		  if( uploader ) {
		    uploader.open();
		    return;
		  }
	
		  // Set the uploader attributes
		  uploader = wp.media({
		    title: mtphr_dnt_image_vars.ml_image_title,
		    button: {
		    	text: mtphr_dnt_image_vars.ml_image_button,
		    	size: 'small'
	    	},
		    multiple: true,
		    library : {
		    	type : 'image'
	    	}
		  });
	
		  uploader.on( 'select', function() {
				attachments = uploader.state().get('selection').toJSON();
				if( attachments.length > 0 ) {
					// Create the display
					var data = {
						action: 'mtphr_dnt_image_ajax',
						attachments: attachments,
						security: mtphr_dnt_image_vars.security
					};
					jQuery.post( ajaxurl, data, function( response ) {
						if( $item == undefined ) {
							$item.after( response );
						} else {
							$table.append( response );
						}
						mtphr_dnt_image_order( $table );
						mtphr_dnt_image_button_toggle( $table );
					});
				}
		  });
	
		  //Open the uploader dialog
		  uploader.open();
	
		  return false;
		}

		$('.mtphr-dnt-image-gallery').each( function(index) {
			$table = $(this);
			mtphr_dnt_image_order( $table );
		});	
	}



});