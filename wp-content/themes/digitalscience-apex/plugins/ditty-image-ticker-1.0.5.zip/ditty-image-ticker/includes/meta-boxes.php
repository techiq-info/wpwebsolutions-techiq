<?php


/* --------------------------------------------------------- */
/* !Add the metabox - 1.0.0 */
/* --------------------------------------------------------- */

function mtphr_dnt_image_setup_metaboxes() {

	function mtphr_dnt_image_metabox() {
		add_meta_box( 'mtphr_dnt_image_data', __('Image Ticker Data', 'ditty-image-ticker'), 'mtphr_dnt_image_render_metabox', 'ditty_news_ticker', 'normal', 'high' );
	}
	add_action( 'add_meta_boxes', 'mtphr_dnt_image_metabox' );
}
add_action( 'admin_init', 'mtphr_dnt_image_setup_metaboxes' );



/* --------------------------------------------------------- */
/* !Render the artist gallery metabox - 1.0.3 */
/* --------------------------------------------------------- */

function mtphr_dnt_image_render_metabox() {

	global $post;

	$options = get_post_meta( $post->ID, '_mtphr_dnt_image_options', true );

	$titles = isset( $options['titles'] ) ? 'on' : '';
	$descriptions = isset( $options['descriptions'] ) ? 'on' : '';
	$links = isset( $options['links'] ) ? 'on' : '';
	$data_hover = isset($options['data_hover']) ? $options['data_hover'] : '';
	$data_display = isset($options['data_display']) ? $options['data_display'] : 'over';
	
	$size = isset( $options['size'] ) ? $options['size'] : '';

	echo '<table class="mtphr-dnt-table mtphr-dnt-image-options">';
		
		echo '<tr>';
			echo '<td class="mtphr-dnt-label">';
				echo '<label>'.__('Toggle image settings', 'ditty-image-ticker').'</label>';
				echo '<small>'.__('Select the elements you would like to use', 'ditty-image-ticker').'</small>';
			echo '</td>';
	    echo '<td>';
	    	echo '<label><input name="_mtphr_dnt_image_options[links]" type="checkbox" value="on" '.checked('on', $links, false).'> '.__('Enable links', 'ditty-image-ticker').'</label>';
	    	echo '<br/>';
	      echo '<label style="margin-right:20px;"><input name="_mtphr_dnt_image_options[titles]" type="checkbox" value="on" '.checked('on', $titles, false).'> '.__('Enable titles', 'ditty-image-ticker').'</label>';
	      echo '<label style="margin-right:20px;"><input name="_mtphr_dnt_image_options[descriptions]" type="checkbox" value="on" '.checked('on', $descriptions, false).'> '.__('Enable descriptions', 'ditty-image-ticker').'</label>';  
	      echo '<label><input name="_mtphr_dnt_image_options[data_hover]" type="checkbox" value="on" '.checked('on', $data_hover, false).' /> '.__('Display data only on hover', 'ditty-instagram-ticker').'</label>';
				echo '<br/>';
				echo '<label style="margin-right:10px;"><input type="radio" name="_mtphr_dnt_image_options[data_display]" value="over" '.checked('over', $data_display, false).' /> '.__('Display data over image', 'ditty-instagram-ticker').'</label>';
				echo '<label><input type="radio" name="_mtphr_dnt_image_options[data_display]" value="out" '.checked('out', $data_display, false).' /> '.__('Display data outside of image', 'ditty-instagram-ticker').'</label>';
			echo '</td>';
	    echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td class="mtphr-dnt-label">';
				echo '<label>'.__('Select an image size', 'ditty-image-ticker').'</label>';
				echo '<small>'.__('Choose the image size you want to display', 'ditty-image-ticker').'</small>';
			echo '</td>';
	    echo '<td>';
	      echo '<select name="_mtphr_dnt_image_options[size]">';
	      	$thumb_sizes = mtphr_dnt_image_get_image_sizes();
	      	foreach( $thumb_sizes as $name => $s ) {
		      	echo '<option value="'.$name.'" '.selected( $name, $size, false ).'>'.$s.'</option>';
	      	}
	      echo '</select>';
	    echo '</td>';
		echo '</tr>';
		
	echo '</table>';

	echo '<input type="hidden" name="mtphr_dnt_image_nonce" value="'.wp_create_nonce(basename(__FILE__)).'" />';
	
	
	
	echo '<table class="mtphr-dnt-table mtphr-dnt-image-gallery-container">';
	
		echo '<tr>';
			echo '<td class="mtphr-dnt-label">';
				echo '<a href="#" class="button-primary mtphr-dnt-image-add-images">'.__('Add Images', 'ditty-image-ticker').'</a>';
			echo '</td>';
		echo '</tr>';
			echo '<td>';
				echo '<table class="mtphr-dnt-image-gallery">';
					
					$ticks = get_post_meta( $post->ID, '_mtphr_dnt_image_ticks', false );
					if( is_array($ticks) && count($ticks) > 0 ) {
						foreach( $ticks as $i=>$data ) {
							mtphr_dnt_image_render_fields( $data, $i );
						}
					}
					
				echo '</table>';
			echo '</td>';
		echo '<tr>';
			
		echo '</tr>';

	echo '</table>';
}

function mtphr_dnt_image_render_fields( $data=false, $i=0 ) {

	$image = isset( $data['image'] ) ? $data['image'] : '';
	$title = isset( $data['title'] ) ? sanitize_text_field($data['title']) : '';
	$description = isset( $data['description'] ) ? wp_kses_post($data['description']) : '';
	$link = isset( $data['link'] ) ? esc_url($data['link']) : '';
	$target = isset( $data['target'] ) ? $data['target'] : '';
	$nofollow = isset( $data['nofollow'] ) ? $data['nofollow'] : '';

	$thumb = wp_get_attachment_image( $image, 'ditty-image-thumb' );

	echo '<tr class="mtphr-dnt-list-item">';
    echo '<td class="mtphr-dnt-list-handle"><span></span></td>';
    echo '<td class="mtphr-dnt-image-list-image">';
    	echo '<input type="hidden" name="_mtphr_dnt_image_ticks['.$i.'][image]" field="image" value="'.$image.'">';
			echo $thumb;
    echo '</td>';
	  echo '<td class="mtphr-dnt-image-list-data">';
	  	echo '<table>';
	  		echo '<tr>';
	  			echo '<td class="mtphr-dnt-image-title mtphr-dnt-image-list-wide">';
						echo '<label>'.__('Title', 'ditty-image-ticker').'</label><br/>';
						echo '<input type="text" name="_mtphr_dnt_image_ticks['.$i.'][title]" field="title" value="'.$title.'">';
					echo '</td>';
					echo '<td class="mtphr-dnt-image-list-narrow mtphr-dnt-image-link">';
						echo '<label>'.__('Link', 'ditty-image-ticker').'</label><br/>';
						echo '<input type="text" name="_mtphr_dnt_image_ticks['.$i.'][link]" field="link" value="'.$link.'">';
					echo '</td>';
	  		echo '</tr>';
	  		echo '<tr>';
					echo '<td>';
						echo '<label>'.__('Description', 'ditty-image-ticker').'</label><br/>';
						echo '<textarea name="_mtphr_dnt_image_ticks['.$i.'][description]" field="description">'.$description.'</textarea>';
					echo '</td>';
					echo '<td class="mtphr-dnt-image-target">';
						echo '<label>'.__('Target', 'ditty-image-ticker').'</label><br/>';
						echo '<select name="_mtphr_dnt_image_ticks['.$i.'][target]" field="target">';
							echo '<option value="_self" '.selected('_self', $target, false).'>_self</option>';
							echo '<option value="_blank" '.selected('_blank', $target, false).'>_blank</option>';
						echo '</select>';
						echo '<label><input type="checkbox" name="_mtphr_dnt_image_ticks['.$i.'][nofollow]" field="nofollow" value="on" '.checked('on', $nofollow, false).'> '.__('nofollow', 'ditty-image-ticker').'</label>';
					echo '</td>';
				echo '</tr>';
			echo '</table>';
		echo '</td>';
		echo '<td class="mtphr-dnt-list-delete"><a href="#"></a></td>';
		echo '<td class="mtphr-dnt-list-add"><a href="#"></a></td>';
	echo '</tr>';
}






/* --------------------------------------------------------- */
/* !Save the custom meta - 1.0.3 */
/* --------------------------------------------------------- */

function mtphr_dnt_image_metabox_save( $post_id ) {

	global $post;

	// verify nonce
	if (!isset($_POST['mtphr_dnt_image_nonce']) || !wp_verify_nonce($_POST['mtphr_dnt_image_nonce'], basename(__FILE__))) {
		return $post_id;
	}

	// check autosave
	if ( (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || ( defined('DOING_AJAX') && DOING_AJAX) || isset($_REQUEST['bulk_edit']) ) return $post_id;

	// don't save if only a revision
	if ( isset($post->post_type) && $post->post_type == 'revision' ) return $post_id;

	// check permissions
	if (isset($_POST['post_type']) && 'page' == $_POST['post_type']) {
		if (!current_user_can('edit_page', $post_id)) {
			return $post_id;
		}
	} elseif (!current_user_can('edit_post', $post_id)) {
		return $post_id;
	}

	// Save the options
	if( isset($_POST['_mtphr_dnt_image_options']) ) {
		update_post_meta( $post_id, '_mtphr_dnt_image_options', $_POST['_mtphr_dnt_image_options'] );
	}

	// Delete the old ticks, save the new ticks
	delete_post_meta( $post_id, '_mtphr_dnt_image_ticks' );
	if( isset($_POST['_mtphr_dnt_image_ticks']) ) {

		foreach( $_POST['_mtphr_dnt_image_ticks'] as $i=>$data ) {

			$sanitized = array();
			$sanitized['image'] = isset( $data['image'] ) ? $data['image'] : '';
			$sanitized['title'] = isset( $data['title'] ) ? sanitize_text_field($data['title']) : '';
			$sanitized['description'] = isset( $data['description'] ) ? wp_kses_post($data['description']) : '';
			$sanitized['data_hover'] = isset( $data['data_hover'] ) ? $data['data_hover'] : '';
			$sanitized['data_display'] = isset( $data['data_display'] ) ? $data['data_display'] : '';
			$sanitized['link'] = isset( $data['link'] ) ? esc_url($data['link']) : '';
			$sanitized['target'] = isset( $data['target'] ) ? $data['target'] : '';
			$sanitized['nofollow'] = isset( $data['nofollow'] ) ? $data['nofollow'] : '';

			add_post_meta( $post_id, '_mtphr_dnt_image_ticks', $sanitized );
		}
	}
}
add_action( 'save_post', 'mtphr_dnt_image_metabox_save' );




