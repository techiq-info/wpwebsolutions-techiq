<?php

/* --------------------------------------------------------- */
/* !Add the ticker type button - 1.0.0 */
/* --------------------------------------------------------- */

function mtphr_dnt_image_type( $types ) {
	$types['image'] = array(
		'button' => __('Image', 'ditty-image-ticker'),
		'metaboxes' => array( 'mtphr_dnt_image_data' )
	);
	return $types;
}
add_filter( 'mtphr_dnt_types', 'mtphr_dnt_image_type' );



/* --------------------------------------------------------- */
/* !Add image sizes - 1.0.0 */
/* --------------------------------------------------------- */

function mtphr_dnt_image_create_image_sizes() {

	if ( function_exists( 'add_image_size' ) ) {
		add_image_size( 'ditty-image-thumb', 150, 150, true );
	}
}
add_action( 'plugins_loaded', 'mtphr_dnt_image_create_image_sizes' );



/* --------------------------------------------------------- */
/* !Get image sizes - 1.0.0 */
/* --------------------------------------------------------- */

if( !function_exists('mtphr_dnt_image_get_image_sizes') ) {
function mtphr_dnt_image_get_image_sizes() {

	// Loop through custom image sizes
	global $_wp_additional_image_sizes;

	$thumb_sizes = array();
	$thumb_sizes['thumbnail'] = __('Thumbnail Size', 'ditty-image-ticker');
	$thumb_sizes['medium'] = __('Medium Size', 'ditty-image-ticker');
	$thumb_sizes['large'] = __('Large Size', 'ditty-image-ticker');
	$thumb_sizes['full'] = __('Full Size', 'ditty-image-ticker');

	if( is_array($_wp_additional_image_sizes) ) {
		$temp_thumb_sizes = array();
		foreach( $_wp_additional_image_sizes as $name => $s ) {
			$temp_dimensions = $s['width'].' x '.$s['height'];
			$dimensions = $s['width'].' x '.$s['height'];
			if( $s['crop'] == 1 ) {
				$temp_dimensions .= ' cropped';
				$dimensions .= ' cropped';
			}
			//$dimensions .= ' ('.$name.')';
			if( !in_array($temp_dimensions, $temp_thumb_sizes) ) {
				$temp_thumb_sizes[$name] = $temp_dimensions;
				$thumb_sizes[$name] = $dimensions;
			}
		}
	}

	return $thumb_sizes;
}
}



/* --------------------------------------------------------- */
/* !Modify the ticks - 1.0.3 */
/* --------------------------------------------------------- */

function mtphr_dnt_image_ticks( $ticks, $id, $meta_data ) {

	if( $meta_data['_mtphr_dnt_type'] == 'image' ) {

		$ticks = mtphr_dnt_get_image_ticks( $id );
		$new_ticks = array();

		if( is_array($ticks) ) {
			foreach ( $ticks as $item ) {
				$new_ticks[] = mtphr_dnt_image_tick( $item, $meta_data );
			}
		}

		// Return the new ticks
		return $new_ticks;
	}

	return $ticks;
}
add_filter( 'mtphr_dnt_tick_array', 'mtphr_dnt_image_ticks', 10, 3 );



/* --------------------------------------------------------- */
/* !Get the image ticks - 1.0.0 */
/* --------------------------------------------------------- */

if( !function_exists('mtphr_dnt_get_image_ticks') ) {
function mtphr_dnt_get_image_ticks( $id ) {
	return get_post_meta( $id, '_mtphr_dnt_image_ticks', false );
}
}



/* --------------------------------------------------------- */
/* !Render a single image tick - 1.0.3 */
/* --------------------------------------------------------- */

if( !function_exists('mtphr_dnt_image_tick') ) {
function mtphr_dnt_image_tick( $item, $meta_data ) {

	$options = $meta_data['_mtphr_dnt_image_options'];
	$titles = isset( $options['titles'] ) ? true : false;
	$descriptions = isset( $options['descriptions'] ) ? true : false;
	$links = isset( $options['links'] ) ? true : false;
	$size = isset( $options['size'] ) ? $options['size'] : 'thumbnail';
	$data_display = isset($options['data_display']) ? $options['data_display'] : 'over';
	$data_hover = (isset($options['data_hover']) && $options['data_hover'] && $data_display == 'over') ? 'mtphr-dnt-image-data-hover' : '';

	$tick = '';
	$image = wp_get_attachment_image_src( $item['image'], $size );

	// Set the container
	if( $links && $item['link'] != '' ) {
		$container_start = '<a href="'.$item['link'].'" target="'.$item['target'].'"';
		if( $item['nofollow'] ) {
			$container_start .= ' rel="nofollow"';
		}
		$container_end = '</a>';
	} else {
		$container_start = '<div';
		$container_end = '</div>';
	}

	// Set the dimensions for scroll mode
	if( $meta_data['_mtphr_dnt_mode'] == 'scroll' ) {
	 	$tick .= $container_start.' class="mtphr-dnt-image-container" style="width:'.$image[1].'px;height:'.$image[2].'px;">';
	} else {
		$tick .= $container_start.' class="mtphr-dnt-image-container">';
	}

	// Add the image
	//$tick .= '<img src="'.$image[0].'" />';
	
	$tick .= '<span class="mtphr-dnt-image-placeholder" data-src="'.$image[0].'" data-width="'.$image[1].'" data-height="'.$image[2].'" style="width:'.$image[1].'px;height:'.$image[2].'px;"><i class="mtphr-dnt-icon-spinner"></i></span>';

	// Add the data container
	if( $titles || $descriptions ) {
		$tick .= '<span class="mtphr-dnt-image-data mtphr-dnt-image-data-'.$data_display.' '.$data_hover.'">';
			if( $titles && $item['title'] != '' ) {
				$tick .= '<span class="mtphr-dnt-image-title">'.sanitize_text_field($item['title']).'</span>';
			}
			if( $descriptions && $item['description'] != '' ) {
				$tick .= '<span class="mtphr-dnt-image-description">'.wp_kses_post($item['description']).'</span>';
			}
		$tick .= '</span>';
	}

	// Close the container
	$tick .= $container_end;

	return apply_filters( 'mtphr_dnt_image_tick', $tick, get_the_id(), $meta_data );
}
}



/* --------------------------------------------------------- */
/* !Set the localization path - 1.0.0 */
/* --------------------------------------------------------- */

function mtphr_dnt_image_localization() {
  load_plugin_textdomain( 'ditty-image-ticker', false, 'ditty-image-ticker/languages/' );
}
add_action( 'plugins_loaded', 'mtphr_dnt_image_localization' );



