<?php

/* --------------------------------------------------------- */
/* !Auto updater script - 1.0.0 */
/* --------------------------------------------------------- */

require 'plugin-updates/plugin-update-checker.php';
$MyUpdateChecker = new PluginUpdateChecker(
	'http://www.metaphorcreations.com/envato/plugins/ditty-image-ticker/auto-update.json',
	'ditty-image-ticker/ditty-image-ticker.php',
	'ditty-image-ticker'
);
//$MyUpdateChecker->checkForUpdates();