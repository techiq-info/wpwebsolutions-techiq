<?php
/*
Plugin Name: Ditty Image Ticker
Plugin URI: http://dittynewsticker.com/ditty-image-ticker/
Description: Add an image ticker type to your <a href="http://wordpress.org/extend/plugins/ditty-image-ticker/">Ditty News Tickers</a>
Version: 1.0.5
Author: Metaphor Creations
Author URI: http://www.metaphorcreations.com
License: GPL2
*/

/*
Copyright 2012 Metaphor Creations  (email : joe@metaphorcreations.com)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/



/* --------------------------------------------------------- */
/* !Define constants - 1.0.5 */
/* --------------------------------------------------------- */

define ( 'MTPHR_DNT_IMAGE_VERSION', '1.0.5' );
define ( 'MTPHR_DNT_IMAGE_DIR', plugin_dir_path(__FILE__) );
define ( 'MTPHR_DNT_IMAGE_URL', plugins_url().'/ditty-image-ticker' );



if( !function_exists('is_plugin_active_for_network') ) {
	require_once( ABSPATH.'/wp-admin/includes/plugin.php' );
}
if( is_plugin_active('ditty-news-ticker/ditty-news-ticker.php') || is_plugin_active_for_network('ditty-news-ticker/ditty-news-ticker.php') ) {

	/* --------------------------------------------------------- */
	/* !Include files - 1.0.0 */
	/* --------------------------------------------------------- */
	
	require_once( MTPHR_DNT_IMAGE_DIR.'includes/scripts.php' );
	require_once( MTPHR_DNT_IMAGE_DIR.'includes/update.php' );
	require_once( MTPHR_DNT_IMAGE_DIR.'includes/functions.php' );
	
	if( is_admin() ) {
		require_once( MTPHR_DNT_IMAGE_DIR.'includes/meta-boxes.php' );
		require_once( MTPHR_DNT_IMAGE_DIR.'includes/ajax.php' );
	}

} else {
	
	
	/* --------------------------------------------------------- */
	/* !Display notice to install Ditty News Ticker - 1.0.1 */
	/* --------------------------------------------------------- */
	
	function mtphr_dnt_image_admin_notice(){
		$url = get_bloginfo('wpurl').'/wp-admin/plugin-install.php?tab=plugin-information&plugin=ditty-news-ticker&TB_iframe=true&width=640&height=500';
    echo '<div class="updated"><p>'.sprintf(__('<a class="thickbox" href="%s"><strong>Ditty News Ticker</strong></a> must be installed and activated to use Ditty Image Ticker.', 'ditty-image-ticker'), $url).'</p></div>';
	}
	add_action('admin_notices', 'mtphr_dnt_image_admin_notice');
}

