jQuery( document ).ready( function($) {
	
	/* --------------------------------------------------------- */
	/* !Edit page functionality - 1.0.7 */
	/* --------------------------------------------------------- */
	
	if( $('#mtphr_dnt_posts_metabox').length > 0 ) {
		mtphr_dnt_posts_settings();
	}
	function mtphr_dnt_posts_settings() {
	
		// Set the initial format field
		var type = $('select[name="_mtphr_dnt_posts_type"]').val();
		mtphr_dnt_posts_format_field( type );
		
		// Set the initial fields
		var orderby = $('select[name="_mtphr_dnt_posts_orderby"]').val();
		if( orderby ) {
			mtphr_dnt_posts_settings_fields( orderby );
		} else {
			mtphr_dnt_posts_settings_fields( 'date' );
		}
		
		// Check for advanced args
		mtphr_dnt_posts_advanced_fields();
		
		// Listen for the post type change
		$('select[name="_mtphr_dnt_posts_type"]').change( function(e) {
			mtphr_dnt_posts_format_field( $(this).val() );		
		});
		
		// Listen for the post order change
		$('select[name="_mtphr_dnt_posts_orderby"]').change( function(e) {
			mtphr_dnt_posts_settings_fields( $(this).val() );		
		});
		
		// Listen for the advanced fields toggle
		$('input[name="_mtphr_dnt_posts_advanced_args_toggle"]').click( function(e) {
			mtphr_dnt_posts_advanced_fields();		
		});
	}
	
	// Set the format field depending on the post type
	function mtphr_dnt_posts_format_field( type ) {
		
		if( $('.mtphr-dnt-posts-format').length > 0 ) {
			if( type == 'post' ) {
				$('.mtphr-dnt-posts-format').show();
			} else {
				$('.mtphr-dnt-posts-format').hide();
			}
		}
	}
	
	// Set the fields depending on the orderby value
	function mtphr_dnt_posts_settings_fields( orderby ) {

		switch( orderby ) {
			
			case 'meta_value':
				
				// Show fields
				$('.mtphr-dnt-posts-orderby-meta-key').show();
				
				break;
				
			case 'meta_value_num':
			
				// Show fields
				$('.mtphr-dnt-posts-orderby-meta-key').show();	
			
				break;
				
			default:

				// Hide fields
				$('.mtphr-dnt-posts-orderby-meta-key').hide();
			
				break;
		}	
	}
	
	function mtphr_dnt_posts_advanced_fields() {
		
		if( $('input[name="_mtphr_dnt_posts_advanced_args_toggle"]').is(':checked') ) {
			
			// Show the advanced fields
			$('.mtphr-dnt-posts-query-args').show();
			$('.mtphr-dnt-posts-taxonomy-args').show();
			$('.mtphr-dnt-posts-taxonomy-relation').show();
		} else {
			
			// Hide the advanced fields
			$('.mtphr-dnt-posts-query-args').hide();
			$('.mtphr-dnt-posts-taxonomy-args').hide();
			$('.mtphr-dnt-posts-taxonomy-relation').hide();
		}
	}
});