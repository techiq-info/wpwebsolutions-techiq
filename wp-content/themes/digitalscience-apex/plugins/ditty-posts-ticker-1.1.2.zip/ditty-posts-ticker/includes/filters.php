<?php


/**
 * Add the posts type to the ticker
 *
 * @since 1.0.0
 */
 
/* --------------------------------------------------------- */
/* !Add the posts type to the ticker - 1.0.7 */
/* --------------------------------------------------------- */

function mtphr_dnt_posts_type( $types ) {
	$types['posts'] = array(
		'button' => __('Posts', 'ditty-posts-ticker'),
		'metaboxes' => array( 'mtphr_dnt_posts_metabox' )
	);
	return $types;
}
add_filter( 'mtphr_dnt_types', 'mtphr_dnt_posts_type' );
