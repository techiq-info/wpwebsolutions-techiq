<?php


/* --------------------------------------------------------- */
/* !Add the posts type metabox - 1.0.7 */
/* --------------------------------------------------------- */

function mtphr_dnt_posts_metabox() {

	add_meta_box( 'mtphr_dnt_posts_metabox', __('Posts Ticker Data', 'ditty-posts-ticker'), 'mtphr_dnt_posts_render_metabox', 'ditty_news_ticker', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'mtphr_dnt_posts_metabox' );



/* --------------------------------------------------------- */
/* !Render the posts type metabox - 1.1.1 */
/* --------------------------------------------------------- */

if( !function_exists('mtphr_dnt_posts_render_metabox') ) {
function mtphr_dnt_posts_render_metabox() {

	global $post;

	$type = get_post_meta( $post->ID, '_mtphr_dnt_posts_type', true );
	$format = get_post_meta( $post->ID, '_mtphr_dnt_posts_format', true );
	
	$limit = get_post_meta( $post->ID, '_mtphr_dnt_posts_limit', true );
	$limit = ( $limit == '' ) ? -1 : $limit;
	
	$orderby = get_post_meta( $post->ID, '_mtphr_dnt_posts_orderby', true );
	$orderby = ( $orderby == '' ) ? 'date' : $orderby;
	$orderby_meta = get_post_meta( $post->ID, '_mtphr_dnt_posts_orderby_meta_key', true );
	$order = get_post_meta( $post->ID, '_mtphr_dnt_posts_order', true );
	$order = ( $order == '' ) ? 'DESC' : $order;
	
	$title = get_post_meta( $post->ID, '_mtphr_dnt_posts_title', true );
	$title_link = get_post_meta( $post->ID, '_mtphr_dnt_posts_title_link', true );
	
	$date = get_post_meta( $post->ID, '_mtphr_dnt_posts_date', true );
	$date_format = get_post_meta( $post->ID, '_mtphr_dnt_posts_date_format', true );
	$date_format = ( $date_format == '' ) ? get_option('date_format') : $date_format;
	
	$thumb = get_post_meta( $post->ID, '_mtphr_dnt_posts_thumb', true );
	$thumb_dimensions = get_post_meta( $post->ID, '_mtphr_dnt_posts_thumb_dimensions', true );
	$thumb_link = get_post_meta( $post->ID, '_mtphr_dnt_posts_thumb_link', true );
	
	$excerpt = get_post_meta( $post->ID, '_mtphr_dnt_posts_excerpt', true );
	$excerpt_length = get_post_meta( $post->ID, '_mtphr_dnt_posts_excerpt_length', true );
	$excerpt_length = ( $excerpt_length == '' ) ? 40 : $excerpt_length;
	$excerpt_more = get_post_meta( $post->ID, '_mtphr_dnt_posts_excerpt_more', true );
	$excerpt_link = get_post_meta( $post->ID, '_mtphr_dnt_posts_excerpt_link', true );
	
	$content = get_post_meta( $post->ID, '_mtphr_dnt_posts_content', true );
	
	$display_order = get_post_meta( $post->ID, '_mtphr_dnt_posts_display_order', true );
	if( !is_array($display_order) ) {
		$display_order = array('title', 'date', 'thumb', 'excerpt', 'content');
		$title = 1;
		$date = 1;
		$excerpt = 1;
		$excerpt_more = '&hellip;{'.__('Read more', 'ditty-posts-ticker').'}';
	}
	
	$advanced = get_post_meta( $post->ID, '_mtphr_dnt_posts_advanced_args_toggle', true );
	$query_args = get_post_meta( $post->ID, '_mtphr_dnt_posts_query_args', true );
	$taxonomy_args = get_post_meta( $post->ID, '_mtphr_dnt_posts_tax_query_args', true );
	$taxonomy_relation = get_post_meta( $post->ID, '_mtphr_dnt_posts_tax_query_relation', true );
	
	// Setup the thumb sizes
	$thumb_sizes = array();
	$thumb_sizes['thumbnail'] = __('Thumbnail Size', 'ditty-posts-ticker');
	$thumb_sizes['medium'] = __('Medium Size', 'ditty-posts-ticker');
	$thumb_sizes['large'] = __('Large Size', 'ditty-posts-ticker');
	$thumb_sizes['full'] = __('Full Size', 'ditty-posts-ticker');
	
	// Loop through custom image sizes
	global $_wp_additional_image_sizes;
	if( is_array($_wp_additional_image_sizes) ) {
		$temp_thumb_sizes = array();
		foreach( $_wp_additional_image_sizes as $name => $size ) {
			$temp_dimensions = $size['width'].' x '.$size['height'];
			$dimensions = $size['width'].' x '.$size['height'];
			if( $size['crop'] == 1 ) {
				$temp_dimensions .= ' cropped';
				$dimensions .= ' cropped';
			}
			//$dimensions .= ' ('.$name.')';
			if( !in_array($temp_dimensions, $temp_thumb_sizes) ) {
				$temp_thumb_sizes[$name] = $temp_dimensions;
				$thumb_sizes[$name] = $dimensions;
			}	
		}
	}

	echo '<input type="hidden" name="mtphr_dnt_posts_nonce" value="'.wp_create_nonce(basename(__FILE__)).'" />';
	
	echo '<table class="mtphr-dnt-table">';

		echo '<tr>';
			echo '<td class="mtphr-dnt-label">';
				echo '<label>'.__('Post type', 'ditty-posts-ticker').'</label>';
				echo '<small>'.__('Select the post type to display', 'ditty-posts-ticker').'</small>';
			echo '</td>';
			echo '<td>';
				$post_types = get_post_types(array('public' => true), 'objects');
				unset( $post_types['ditty_news_ticker'] );
				if( is_array($post_types) && count($post_types) > 0 ) {
					echo '<label style="margin-right:20px;"><select name="_mtphr_dnt_posts_type">';
					foreach( $post_types as $i=>$pt ) {
						echo '<option value="'.$i.'" '.selected($i, $type, false).'>'.$pt->labels->name.'</option>';
					}
					echo '</select></label>';
				}
				if( current_theme_supports('post-formats') ) { 
	        echo '<label class="mtphr-dnt-posts-format">'.__('Post format', 'ditty-posts-ticker').' <select name="_mtphr_dnt_posts_format">';
	        	echo '<option value="">'.__('Any Format', 'ditty-posts-ticker').'</option>';
	        	$post_formats = get_theme_support( 'post-formats' );
						if( is_array($post_formats[0]) ) {
							foreach( $post_formats[0] as $i=>$pf ) {
								echo '<option value="'.$pf.'" '.selected($pf, $format, false).'>'.ucfirst($pf).'</option>';
							}
						}
					echo '</select></label>';
				}
			echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td class="mtphr-dnt-label">';
				echo '<label>'.__('Post limit', 'ditty-posts-ticker').'</label>';
				echo '<small>'.__('Limit the number of posts to show per page (set to -1 for all)', 'ditty-posts-ticker').'</small>';
			echo '</td>';
			echo '<td>';
				echo '<label><input type="number" name="_mtphr_dnt_posts_limit" value="'.$limit.'" /> '.__('Limit', 'ditty-posts-ticker').'</label>';
			echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td class="mtphr-dnt-label">';
				echo '<label>'.__('Post order', 'ditty-posts-ticker').'</label>';
				echo '<small>'.__('Set the order and orderby parameters', 'ditty-posts-ticker').'</small>';
			echo '</td>';
			echo '<td>';
				echo '<label style="margin-right:20px;">'.__('Orderby', 'ditty-posts-ticker').' <select name="_mtphr_dnt_posts_orderby">';
					echo '<option value="ID" '.selected('ID', $orderby, false).'>'.__('ID', 'ditty-posts-ticker').'</option>';
					echo '<option value="author" '.selected('author', $orderby, false).'>'.__('Author', 'ditty-posts-ticker').'</option>';
					echo '<option value="title" '.selected('title', $orderby, false).'>'.__('Title', 'ditty-posts-ticker').'</option>';
					echo '<option value="name" '.selected('name', $orderby, false).'>'.__('Name', 'ditty-posts-ticker').'</option>';
					echo '<option value="date" '.selected('date', $orderby, false).'>'.__('Date', 'ditty-posts-ticker').'</option>';
					echo '<option value="modified" '.selected('modified', $orderby, false).'>'.__('Modified', 'ditty-posts-ticker').'</option>';
					echo '<option value="parent" '.selected('parent', $orderby, false).'>'.__('Parent', 'ditty-posts-ticker').'</option>';
					echo '<option value="rand" '.selected('rand', $orderby, false).'>'.__('Random', 'ditty-posts-ticker').'</option>';
					echo '<option value="comment_count" '.selected('comment_count', $orderby, false).'>'.__('Comment Count', 'ditty-posts-ticker').'</option>';
					echo '<option value="menu_order" '.selected('menu_order', $orderby, false).'>'.__('Menu Order', 'ditty-posts-ticker').'</option>';
					echo '<option value="meta_value" '.selected('meta_value', $orderby, false).'>'.__('Meta Value', 'ditty-posts-ticker').'</option>';
					echo '<option value="meta_value_num" '.selected('meta_value_num', $orderby, false).'>'.__('Meta Value Number', 'ditty-posts-ticker').'</option>';
					echo '<option value="post__in" '.selected('post__in', $orderby, false).'>'.__('Post In', 'ditty-posts-ticker').'</option>';
				echo '</select></label>';
				echo '<label class="mtphr-dnt-posts-orderby-meta-key" style="margin-right:20px;">'.__('Meta Key', 'ditty-posts-ticker').' <input style="width:100px;" type="text" name="_mtphr_dnt_posts_orderby_meta_key" value="'.$orderby_meta.'" /></label>';
				echo '<label>'.__('Order', 'ditty-posts-ticker').' <select name="_mtphr_dnt_posts_order">';
					echo '<option value="ASC" '.selected('ASC', $order, false).'>'.__('Ascending', 'ditty-posts-ticker').'</option>';
					echo '<option value="DESC" '.selected('DESC', $order, false).'>'.__('Descending', 'ditty-posts-ticker').'</option>';
				echo '</select></label>';
			echo '</td>';
		echo '</tr>';
		
		if( !current_theme_supports('ditty_posts_ticker_templates') ) {
			echo '<tr>';
				echo '<td class="mtphr-dnt-label">';
					echo '<label>'.__('Post arrangement', 'ditty-posts-ticker').'</label>';
					echo '<small>'.__('Set the post assets and order', 'ditty-posts-ticker').'</small>';
				echo '</td>';
				echo '<td>';
					echo '<table class="mtphr-dnt-sort-list mtphr-dnt-posts-assets">';
						if( is_array($display_order) && count($display_order) > 0 ) {
							foreach( $display_order as $ds ) {
								switch( $ds ) {
									case 'title':
										echo '<tr class="mtphr-dnt-list-item">';
											echo '<td class="mtphr-dnt-list-handle"><span></span></td>';
											echo '<td>';
												echo '<input type="hidden" name="_mtphr_dnt_posts_display_order[]" value="title" />';
												echo '<label style="margin-right:20px;"><strong>'.__('Post title', 'ditty-posts-ticker').'</strong> <input type="checkbox" name="_mtphr_dnt_posts_title" value="1" '.checked(1, $title, false).' /></label>';
												echo '<label><input type="checkbox" name="_mtphr_dnt_posts_title_link" value="1" '.checked(1, $title_link, false).' /> '.__('Link to post', 'ditty-posts-ticker').'</label>';
											echo '</td>';
										echo '</tr>';
										break;
									case 'date':
										echo '<tr class="mtphr-dnt-list-item">';
											echo '<td class="mtphr-dnt-list-handle"><span></span></td>';
											echo '<td>';
												echo '<input type="hidden" name="_mtphr_dnt_posts_display_order[]" value="date" />';
												echo '<label style="margin-right:20px;"><strong>'.__('Post date', 'ditty-posts-ticker').'</strong> <input type="checkbox" name="_mtphr_dnt_posts_date" value="1" '.checked(1, $date, false).' /></label>';
												echo '<label>'.__('Format', 'ditty-posts-ticker').' <input style="width:80px;" type="text" name="_mtphr_dnt_posts_date_format" value="'.$date_format.'" /></label>';
											echo '</td>';
										echo '</tr>';
										break;
									case 'thumb':
										echo '<tr class="mtphr-dnt-list-item">';
											echo '<td class="mtphr-dnt-list-handle"><span></span></td>';
											echo '<td>';
												echo '<input type="hidden" name="_mtphr_dnt_posts_display_order[]" value="thumb" />';
												echo '<label style="margin-right:20px;"><strong>'.__('Post thumbnail', 'ditty-posts-ticker').'</strong> <input type="checkbox" name="_mtphr_dnt_posts_thumb" value="1" '.checked(1, $thumb, false).' /></label>';
												if( is_array($thumb_sizes) && count($thumb_sizes) > 0 ) {
													echo '<select style="margin-right:20px;" name="_mtphr_dnt_posts_thumb_dimensions">';
													foreach( $thumb_sizes as $i=>$ts ) {
														echo '<option value="'.$i.'" '.selected($i, $thumb_dimensions, false).'>'.$ts.'</option>';
													}
													echo '</select>';
												}
												echo '<label><input type="checkbox" name="_mtphr_dnt_posts_thumb_link" value="1" '.checked(1, $thumb_link, false).' /> '.__('Link to post', 'ditty-posts-ticker').'</label>';
											echo '</td>';
										echo '</tr>';
										break;
									case 'excerpt':
										echo '<tr class="mtphr-dnt-list-item">';
											echo '<td class="mtphr-dnt-list-handle"><span></span></td>';
											echo '<td>';
												echo '<input type="hidden" name="_mtphr_dnt_posts_display_order[]" value="excerpt" />';
												echo '<label style="margin-right:20px;"><strong>'.__('Post excerpt', 'ditty-posts-ticker').'</strong> <input type="checkbox" name="_mtphr_dnt_posts_excerpt" value="1" '.checked(1, $excerpt, false).' /></label>';
												echo '<label style="margin-right:20px;">'.__('Excerpt length', 'ditty-posts-ticker').' <input style="width:50px;" type="number" name="_mtphr_dnt_posts_excerpt_length" value="'.$excerpt_length.'" /></label>';
												echo '<label style="margin-right:20px;">'.__('Excerpt more', 'ditty-posts-ticker').' <input style="width:80px;" type="text" name="_mtphr_dnt_posts_excerpt_more" value="'.$excerpt_more.'" /></label>';
												echo '<label><input type="checkbox" name="_mtphr_dnt_posts_excerpt_link" value="1" '.checked(1, $excerpt_link, false).' /> '.__('Link to post', 'ditty-posts-ticker').'</label>';
											echo '</td>';
										echo '</tr>';
										break;
									case 'content':
										echo '<tr class="mtphr-dnt-list-item">';
											echo '<td class="mtphr-dnt-list-handle"><span></span></td>';
											echo '<td>';
												echo '<input type="hidden" name="_mtphr_dnt_posts_display_order[]" value="content" />';
												echo '<label><strong>'.__('Post content', 'ditty-posts-ticker').'</strong> <input type="checkbox" name="_mtphr_dnt_posts_content" value="1" '.checked(1, $content, false).' /></label>';
											echo '</td>';
										echo '</tr>';
										break;
								}
							}
						}
					echo '</table>';
				echo '</td>';
			echo '</tr>';
		}
		
		echo '<tr>';
			echo '<td class="mtphr-dnt-label" colspan="2">';
				echo '<label><input type="checkbox" name="_mtphr_dnt_posts_advanced_args_toggle" value="1" '.checked(1, $advanced, false).' /> '.__('Advanced options', 'ditty-posts-ticker').'</label>';
			echo '</td>';
		echo '</tr>';
		
		echo '<tr class="mtphr-dnt-posts-query-args">';
			echo '<td class="mtphr-dnt-label">';
				echo '<label>'.__('Query args', 'ditty-posts-ticker').'</label>';
				echo '<small>'.__('Add query args for advanced post queries', 'ditty-posts-ticker').'</small>';
			echo '</td>';
			echo '<td>';
				echo '<table class="mtphr-dnt-advanced-list">';
					echo '<tr>';
						echo '<th class="mtphr-dnt-list-handle"></th>';
						echo '<th class="mtphr-dnt-posts-query-parameter">'.__('Parameter', 'ditty-posts-ticker').'</th>';
						echo '<th class="mtphr-dnt-posts-query-value">'.__('Value', 'ditty-posts-ticker').'</th>';
						echo '<th class="mtphr-dnt-posts-query-split">'.__('Create array', 'ditty-posts-ticker').'</th>';
						echo '<th class="mtphr-dnt-list-delete"></th>';
						echo '<th class="mtphr-dnt-list-add"></th>';
					echo '</tr>';
					if( is_array($query_args) && count($query_args) > 0 ) {
						foreach( $query_args as $i=>$data ) {
							mtphr_dnt_posts_render_query_args( $data );
						}
					} else {
						mtphr_dnt_posts_render_query_args();
					}
				echo '</table>';
			echo '</td>';
		echo '</tr>';
		
		echo '<tr class="mtphr-dnt-posts-taxonomy-args">';
			echo '<td class="mtphr-dnt-label">';
				echo '<label>'.__('Taxonomy args', 'ditty-posts-ticker').'</label>';
				echo '<small>'.__('Add taxonomy query args for advanced post queries', 'ditty-posts-ticker').'</small>';
			echo '</td>';
			echo '<td>';
				echo '<table class="mtphr-dnt-advanced-list">';
					echo '<tr>';
						echo '<th class="mtphr-dnt-list-handle"></th>';
						echo '<th class="mtphr-dnt-posts-query-taxonomy">'.__('Taxonomy', 'ditty-posts-ticker').'</th>';
						echo '<th class="mtphr-dnt-posts-query-field">'.__('Field', 'ditty-posts-ticker').'</th>';
						echo '<th class="mtphr-dnt-posts-query-terms">'.__('Term(s)', 'ditty-posts-ticker').'</th>';
						echo '<th class="mtphr-dnt-posts-query-children">'.__('Children', 'ditty-posts-ticker').'</th>';
						echo '<th class="mtphr-dnt-posts-query-operator">'.__('Operator', 'ditty-posts-ticker').'</th>';
						echo '<th class="mtphr-dnt-list-delete"></th>';
						echo '<th class="mtphr-dnt-list-add"></th>';
					echo '</tr>';
					if( is_array($taxonomy_args) && count($taxonomy_args) > 0 ) {
						foreach( $taxonomy_args as $i=>$data ) {
							mtphr_dnt_posts_render_taxonomy_args( $data );
						}
					} else {
						mtphr_dnt_posts_render_taxonomy_args();
					}
				echo '</table>';
			echo '</td>';
		echo '</tr>';
		
		echo '<tr class="mtphr-dnt-posts-taxonomy-relation">';
			echo '<td class="mtphr-dnt-label">';
				echo '<label>'.__('Taxonomy relation', 'ditty-posts-ticker').'</label>';
				echo '<small>'.__('Select the relation between multiple taxonomies', 'ditty-posts-ticker').'</small>';
			echo '</td>';
			echo '<td>';
				echo '<select name="_mtphr_dnt_posts_tax_query_relation">';
					echo '<option value="AND" '.selected('AND', $taxonomy_relation, false).'>'.__('And', 'ditty-posts-ticker').'</option>';
					echo '<option value="OR" '.selected('OR', $taxonomy_relation, false).'>'.__('Or', 'ditty-posts-ticker').'</option>';
				echo '</select>';
			echo '</td>';
		echo '</tr>';
		
	echo '</table>';
}
}

if( !function_exists('mtphr_dnt_posts_render_query_args') ) {
function mtphr_dnt_posts_render_query_args( $data=false ) {

	$parameter = ( $data && isset($data['parameter']) ) ? $data['parameter'] : '';
	$value = ( $data && isset($data['value']) ) ? $data['value'] : '';
	$split = ( $data && isset($data['split']) ) ? $data['split'] : '';

	echo '<tr class="mtphr-dnt-list-item">';
		echo '<td class="mtphr-dnt-list-handle"><span></span></td>';
		
		echo '<td class="mtphr-dnt-posts-query-parameter">';
			echo '<input type="text" name="_mtphr_dnt_posts_query_args[parameter]" data-name="_mtphr_dnt_posts_query_args" data-key="parameter" value="'.$parameter.'" />';
		echo '</td>';
		echo '<td class="mtphr-dnt-posts-query-value">';
			echo '<input type="text" name="_mtphr_dnt_posts_query_args[value]" data-name="_mtphr_dnt_posts_query_args" data-key="value" value="'.$value.'" />';
		echo '</td>';
		echo '<td class="mtphr-dnt-posts-query-split">';
			echo '<label><input type="checkbox" name="_mtphr_dnt_posts_query_args[split]" data-name="_mtphr_dnt_posts_query_args" data-key="split" value="1" '.checked(1, $split, false).' /> '.__('Split list', 'ditty-posts-ticker').'</label>';
		echo '</td>';
		echo '<td class="mtphr-dnt-list-delete"><a href="#"></a></td>';
		echo '<td class="mtphr-dnt-list-add"><a href="#"></a></td>';
	echo '</tr>';
}
}

if( !function_exists('mtphr_dnt_posts_render_taxonomy_args') ) {
function mtphr_dnt_posts_render_taxonomy_args( $data=false ) {

	$taxonomy = ( $data && isset($data['taxonomy']) ) ? $data['taxonomy'] : '';
	$field = ( $data && isset($data['field']) ) ? $data['field'] : '';
	$terms = ( $data && isset($data['terms']) ) ? $data['terms'] : '';
	$children = ( $data && isset($data['children']) ) ? $data['children'] : '';
	$operator = ( $data && isset($data['operator']) ) ? $data['operator'] : '';

	echo '<tr class="mtphr-dnt-list-item">';
		echo '<td class="mtphr-dnt-list-handle"><span></span></td>';
		
		echo '<td class="mtphr-dnt-posts-query-taxonomy">';
			echo '<input type="text" name="_mtphr_dnt_posts_tax_query_args[taxonomy]" data-name="_mtphr_dnt_posts_tax_query_args" data-key="taxonomy" value="'.$taxonomy.'" />';
		echo '</td>';
		echo '<td class="mtphr-dnt-posts-query-field">';
			echo '<select name="_mtphr_dnt_posts_tax_query_args[field]" data-name="_mtphr_dnt_posts_tax_query_args" data-key="field">';
				echo '<option value="id" '.selected('id', $field, false).'>'.__('ID', 'ditty-posts-ticker').'</option>';
				echo '<option value="slug" '.selected('slug', $field, false).'>'.__('Slug', 'ditty-posts-ticker').'</option>';
			echo '</td>';
		echo '</td>';
		echo '<td class="mtphr-dnt-posts-query-terms">';
			echo '<input type="text" name="_mtphr_dnt_posts_tax_query_args[terms]" data-name="_mtphr_dnt_posts_tax_query_args" data-key="terms" value="'.$terms.'" />';
		echo '</td>';
		echo '<td class="mtphr-dnt-posts-query-children">';
			echo '<input type="checkbox" name="_mtphr_dnt_posts_tax_query_args[children]" data-name="_mtphr_dnt_posts_tax_query_args" data-key="children" value="1" '.checked(1, $children, false).' />';
		echo '</td>';
		echo '<td class="mtphr-dnt-posts-query-operatory">';
			echo '<select name="_mtphr_dnt_posts_tax_query_args[operator]" data-name="_mtphr_dnt_posts_tax_query_args" data-key="operator">';
				echo '<option value="IN" '.selected('IN', $operator, false).'>'.__('In', 'ditty-posts-ticker').'</option>';
				echo '<option value="NOT IN" '.selected('NOT IN', $operator, false).'>'.__('Not In', 'ditty-posts-ticker').'</option>';
				echo '<option value="AND" '.selected('AND', $operator, false).'>'.__('And', 'ditty-posts-ticker').'</option>';
			echo '</td>';
		echo '</td>';
	  
		echo '<td class="mtphr-dnt-list-delete"><a href="#"></a></td>';
		echo '<td class="mtphr-dnt-list-add"><a href="#"></a></td>';
	echo '</tr>';
}
}



/* --------------------------------------------------------- */
/* !Save the custom meta - 1.0.9 */
/* --------------------------------------------------------- */

function mtphr_dnt_posts_metabox_save( $post_id ) {

	global $post;

	// verify nonce
	if (!isset($_POST['mtphr_dnt_posts_nonce']) || !wp_verify_nonce($_POST['mtphr_dnt_posts_nonce'], basename(__FILE__))) {
		return $post_id;
	}

	// check autosave
	if ( (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || ( defined('DOING_AJAX') && DOING_AJAX) || isset($_REQUEST['bulk_edit']) ) return $post_id;

	// don't save if only a revision
	if ( isset($post->post_type) && $post->post_type == 'revision' ) return $post_id;

	// check permissions
	if (isset($_POST['post_type']) && 'page' == $_POST['post_type']) {
		if (!current_user_can('edit_page', $post_id)) {
			return $post_id;
		}
	} elseif (!current_user_can('edit_post', $post_id)) {
		return $post_id;
	}
	
	// Update the type & mode
	if( isset($_POST['_mtphr_dnt_posts_type']) ) {

		$type = isset($_POST['_mtphr_dnt_posts_type']) ? $_POST['_mtphr_dnt_posts_type'] : '';
		$format = isset($_POST['_mtphr_dnt_posts_format']) ? $_POST['_mtphr_dnt_posts_format'] : '';
		$limit = isset($_POST['_mtphr_dnt_posts_limit']) ? intval($_POST['_mtphr_dnt_posts_limit']) : -1;
		$orderby = isset($_POST['_mtphr_dnt_posts_orderby']) ? $_POST['_mtphr_dnt_posts_orderby'] : '';
		$orderby_meta = isset($_POST['_mtphr_dnt_posts_orderby_meta_key']) ? sanitize_text_field($_POST['_mtphr_dnt_posts_orderby_meta_key']) : '';
		$order = isset($_POST['_mtphr_dnt_posts_order']) ? $_POST['_mtphr_dnt_posts_order'] : '';
		$display_order = isset($_POST['_mtphr_dnt_posts_display_order']) ? $_POST['_mtphr_dnt_posts_display_order'] : '';
		$title = isset($_POST['_mtphr_dnt_posts_title']) ? $_POST['_mtphr_dnt_posts_title'] : '';
		$title_link = isset($_POST['_mtphr_dnt_posts_title_link']) ? $_POST['_mtphr_dnt_posts_title_link'] : '';
		$date = isset($_POST['_mtphr_dnt_posts_date']) ? $_POST['_mtphr_dnt_posts_date'] : '';
		$date_format = isset($_POST['_mtphr_dnt_posts_date_format']) ? sanitize_text_field($_POST['_mtphr_dnt_posts_date_format']) : '';	
		$thumb = isset($_POST['_mtphr_dnt_posts_thumb']) ? $_POST['_mtphr_dnt_posts_thumb'] : '';
		$thumb_dimensions = isset($_POST['_mtphr_dnt_posts_thumb_dimensions']) ? $_POST['_mtphr_dnt_posts_thumb_dimensions'] : '';
		$thumb_link = isset($_POST['_mtphr_dnt_posts_thumb_link']) ? $_POST['_mtphr_dnt_posts_thumb_link'] : '';
		$excerpt = isset($_POST['_mtphr_dnt_posts_excerpt']) ? $_POST['_mtphr_dnt_posts_excerpt'] : '';
		$excerpt_length = isset($_POST['_mtphr_dnt_posts_excerpt_length']) ? intval($_POST['_mtphr_dnt_posts_excerpt_length']) : '';
		$excerpt_more = isset($_POST['_mtphr_dnt_posts_excerpt_more']) ? wp_kses_post($_POST['_mtphr_dnt_posts_excerpt_more']) : '';
		$excerpt_link = isset($_POST['_mtphr_dnt_posts_excerpt_link']) ? $_POST['_mtphr_dnt_posts_excerpt_link'] : '';
		$content = isset($_POST['_mtphr_dnt_posts_content']) ? $_POST['_mtphr_dnt_posts_content'] : '';
		$advanced = isset($_POST['_mtphr_dnt_posts_advanced_args_toggle']) ? $_POST['_mtphr_dnt_posts_advanced_args_toggle'] : '';
		$query_args = isset($_POST['_mtphr_dnt_posts_query_args']) ? $_POST['_mtphr_dnt_posts_query_args'] : '';
		$sanitized_query_args = array();
		if( is_array($query_args) && count($query_args) > 0 ) {
			foreach( $query_args as $i=>$data ) {
				$sanitized_query_args[] = array(
					'parameter' => isset($data['parameter']) ? sanitize_text_field($data['parameter']) : '',
					'value' => isset($data['value']) ? sanitize_text_field($data['value']) : '',
					'split' => isset($data['split']) ? $data['split'] : ''
				);
			}
		}
		
		$taxonomy_args = isset($_POST['_mtphr_dnt_posts_tax_query_args']) ? $_POST['_mtphr_dnt_posts_tax_query_args'] : '';
		$sanitized_taxonomy_args = array();
		if( is_array($taxonomy_args) && count($taxonomy_args) > 0 ) {
			foreach( $taxonomy_args as $i=>$data ) {
				$sanitized_taxonomy_args[] = array(
					'taxonomy' => isset($data['taxonomy']) ? sanitize_text_field($data['taxonomy']) : '',
					'field' => isset($data['field']) ? $data['field'] : '',
					'terms' => isset($data['terms']) ? sanitize_text_field($data['terms']) : '',
					'children' => isset($data['children']) ? $data['children'] : '',
					'operator' => isset($data['operator']) ? $data['operator'] : ''
				);
			}
		}
		
		$taxonomy_relation = isset($_POST['_mtphr_dnt_posts_tax_query_relation']) ? $_POST['_mtphr_dnt_posts_tax_query_relation'] : '';
		
		update_post_meta( $post_id, '_mtphr_dnt_posts_type', $type );
		update_post_meta( $post_id, '_mtphr_dnt_posts_format', $format );
		update_post_meta( $post_id, '_mtphr_dnt_posts_limit', $limit );
		update_post_meta( $post_id, '_mtphr_dnt_posts_orderby', $orderby );
		update_post_meta( $post_id, '_mtphr_dnt_posts_orderby_meta_key', $orderby_meta );
		update_post_meta( $post_id, '_mtphr_dnt_posts_order', $order );
		update_post_meta( $post_id, '_mtphr_dnt_posts_display_order', $display_order );
		update_post_meta( $post_id, '_mtphr_dnt_posts_title', $title );
		update_post_meta( $post_id, '_mtphr_dnt_posts_title_link', $title_link );
		update_post_meta( $post_id, '_mtphr_dnt_posts_date', $date );
		update_post_meta( $post_id, '_mtphr_dnt_posts_date_format', $date_format );
		update_post_meta( $post_id, '_mtphr_dnt_posts_thumb', $thumb );
		update_post_meta( $post_id, '_mtphr_dnt_posts_thumb_dimensions', $thumb_dimensions );
		update_post_meta( $post_id, '_mtphr_dnt_posts_thumb_link', $thumb_link );
		update_post_meta( $post_id, '_mtphr_dnt_posts_excerpt', $excerpt );
		update_post_meta( $post_id, '_mtphr_dnt_posts_excerpt_length', $excerpt_length );
		update_post_meta( $post_id, '_mtphr_dnt_posts_excerpt_more', $excerpt_more );
		update_post_meta( $post_id, '_mtphr_dnt_posts_excerpt_link', $excerpt_link );
		update_post_meta( $post_id, '_mtphr_dnt_posts_content', $content );
		update_post_meta( $post_id, '_mtphr_dnt_posts_advanced_args_toggle', $advanced );
		update_post_meta( $post_id, '_mtphr_dnt_posts_query_args', $sanitized_query_args );
		update_post_meta( $post_id, '_mtphr_dnt_posts_tax_query_args', $sanitized_taxonomy_args );
		update_post_meta( $post_id, '_mtphr_dnt_posts_tax_query_relation', $taxonomy_relation );
	}
}
add_action( 'save_post', 'mtphr_dnt_posts_metabox_save' );
