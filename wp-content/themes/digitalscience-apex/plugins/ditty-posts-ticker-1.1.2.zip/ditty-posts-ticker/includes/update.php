<?php

/* --------------------------------------------------------- */
/* !Auto updater script - 1.0.5 */
/* --------------------------------------------------------- */

require 'plugin-updates/plugin-update-checker.php';
$MyUpdateChecker = new PluginUpdateChecker(
	'http://www.metaphorcreations.com/envato/plugins/ditty-posts-ticker/auto-update.json',
	'ditty-posts-ticker/ditty-posts-ticker.php',
	'ditty-posts-ticker'
);
//$MyUpdateChecker->checkForUpdates();



/* --------------------------------------------------------- */
/* !Update to version 1.0.7 */
/* Update list paging meta with previous posts paging meta
/* --------------------------------------------------------- */

function mtphr_dnt_posts_update_1_0_7() {

	if( !get_option('mtphr_dnt_posts_update_1_0_7') ) {
	
		$args = array(
			'posts_per_page' => -1,
			'meta_key' => '_mtphr_dnt_type',
			'meta_value' => 'posts',
			'post_type' => 'ditty_news_ticker'
		);
		$tickers = get_posts( $args );
		if( is_array($tickers) && count($tickers) > 0 ) {
			foreach( $tickers as $i=>$ticker ) {
				
				$paged = get_post_meta( $ticker->ID, '_mtphr_dnt_posts_paged', true );
				if( $paged == 'navigation' || $paged == 'pagination' ) {
					$limit = get_post_meta( $ticker->ID, '_mtphr_dnt_posts_limit', true );
					$prev = get_post_meta( $ticker->ID, '_mtphr_dnt_posts_prev_text', true );
					$next = get_post_meta( $ticker->ID, '_mtphr_dnt_posts_next_text', true );
					
					update_post_meta( $ticker->ID, '_mtphr_dnt_list_tick_paging', 1 );
					update_post_meta( $ticker->ID, '_mtphr_dnt_list_tick_count', $limit );
					update_post_meta( $ticker->ID, '_mtphr_dnt_list_tick_prev_text', $prev );
					update_post_meta( $ticker->ID, '_mtphr_dnt_list_tick_next_text', $next );
					if( $page == 'navigation' ) {
						update_post_meta( $ticker->ID, '_mtphr_dnt_list_tick_prev_next', 1 );
					}
				}
			}
		}		
		update_option( 'mtphr_dnt_posts_update_1_0_7', 'updated' );
	}	
}
add_action( 'init', 'mtphr_dnt_posts_update_1_0_7' );