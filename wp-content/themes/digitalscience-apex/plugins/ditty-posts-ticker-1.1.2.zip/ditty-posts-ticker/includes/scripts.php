<?php
/**
 * Load CSS & jQuery Scripts
 *
 * @package Ditty News Ticker - Posts
 */




add_action( 'admin_enqueue_scripts', 'mtphr_dnt_posts_admin_scripts' );
/**
 * Load the metaboxer scripts
 *
 * @since 1.0.0
 */
function mtphr_dnt_posts_admin_scripts( $hook ) {
	
	global $typenow;

	if ( $typenow == 'ditty_news_ticker' ) {
	
		// Load the news ticker posts style
		wp_register_style( 'ditty-news-ticker-posts', MTPHR_DNT_POSTS_URL.'assets/css/style-admin.css', false, MTPHR_DNT_POSTS_VERSION );
		wp_enqueue_style( 'ditty-news-ticker-posts' );
		
		// Load the news ticker posts script
		wp_register_script( 'ditty-news-ticker-posts', MTPHR_DNT_POSTS_URL.'assets/js/script.js', array( 'jquery' ), MTPHR_DNT_POSTS_VERSION, true );
		wp_enqueue_script( 'ditty-news-ticker-posts' );
	}
}




add_action( 'wp_enqueue_scripts', 'mtphr_dnt_posts_scripts' );
/**
 * Load the front end scripts
 *
 * @since 1.0.0
 */
function mtphr_dnt_posts_scripts() {
	
	// Load the css
	wp_register_style( 'ditty-news-ticker-posts', MTPHR_DNT_POSTS_URL.'assets/css/style.css', false, MTPHR_DNT_POSTS_VERSION );
	wp_enqueue_style( 'ditty-news-ticker-posts' );
}

