<div class="entry-content clearfix">

	<?php
	the_post_thumbnail( 'apex-featured-short', array('class'=>'entry-featured aligncenter') );
	the_content();
	apex_link_pages();
	?>

</div><!-- .entry-content -->