<div class="entry-featured">
	<?php echo apex_quote_thumbnail(); ?>
</div>

<div class="entry-content clearfix">
	<?php the_content(); ?>
</div>

<div class="entry-title">
	<?php the_title(); ?>
</div>