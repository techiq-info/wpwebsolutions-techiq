<div class="entry-content clearfix">

	<?php
	the_content();
	apex_link_pages();
	?>

</div><!-- .entry-content -->